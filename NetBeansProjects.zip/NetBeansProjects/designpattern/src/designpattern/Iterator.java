/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package designpattern;


public interface Iterator {
    public boolean hasNext();
    public Object next();
    public boolean hasPrevious(); // New method for checking previous element
    public Object previous();     // New method for getting the previous element
}