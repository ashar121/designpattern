/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package strategypattern;

/**
 *
 * @author fa20-bse-019
 */
public class StrategyPatternDemo {
   public static void main(String[] args) {
      Context context = new Context(new OperationAdd());		
      System.out.println("100 + 20 = " + context.executeStrategy(100, 20));

      context = new Context(new OperationSubstract());		
      System.out.println("100 - 20 = " + context.executeStrategy(100, 20));

      context = new Context(new OperationMultiply());		
      System.out.println("100 * 20 = " + context.executeStrategy(100, 20));
   }
}